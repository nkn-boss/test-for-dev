import { LightningElement, track } from 'lwc';
import add from '@salesforce/apex/Calculator.add';
import subtract from '@salesforce/apex/Calculator.subtract';
import multiply from '@salesforce/apex/Calculator.multiply';
import divide from '@salesforce/apex/Calculator.divide';

export default class CalculatorComponent extends LightningElement {
    @track number1;
    @track number2;
    @track result;

    handleAdd() {
        add({ num1: this.number1, num2: this.number2 })
            .then(result => {
                this.result = result;
            })
            .catch(error => {
                this.result = error.body.message;
            });
    }

    handleSubtract() {
        subtract({ num1: this.number1, num2: this.number2 })
            .then(result => {
                this.result = result;
            })
            .catch(error => {
                this.result = error.body.message;
            });
    }

    handleMultiply() {
        multiply({ num1: this.number1, num2: this.number2 })
            .then(result => {
                this.result = result;
            })
            .catch(error => {
                this.result = error.body.message;
            });
    }

    handleDivide() {
        divide({ num1: this.number1, num2: this.number2 })
            .then(result => {
                this.result = result;
            })
            .catch(error => {
                this.result = error.body.message;
            });
    }
}